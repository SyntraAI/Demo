/*
  Vacancy Match demo
  - Static, no external browsing
  - Uses a small in-memory "public profile" dataset
  - Ranks candidates based on keyword overlap + role similarity + optional location/seniority hints
*/

const $ = (id) => document.getElementById(id);

const vacancyTextEl = $("vacancyText");
const vacancyLocationEl = $("vacancyLocation");
const vacancySeniorityEl = $("vacancySeniority");
const findBtn = $("findMatchesBtn");
const resultsList = $("resultsList");
const resultsEmpty = $("resultsEmpty");
const resultsCountPill = $("resultsCountPill");

// --- Mock "public web profiles" ---
// In production: replace with search-provider discovery + enrichment pipeline.
const CANDIDATES = [
  {
    name: "Sanne de Vries",
    headline: "Senior Data Scientist | Forecasting & Optimisation (Supply Chain)",
    location: "Amsterdam, NL",
    seniority: "senior",
    skills: ["python", "pandas", "time series", "forecasting", "inventory", "optimisation", "or", "stakeholder", "azure", "databricks"],
    highlights: ["Built demand forecasting models for retail distribution", "Reduced stock-outs by 12% via inventory optimisation"],
    sourceHint: "LinkedIn / public profile",
  },
  {
    name: "Marco Jansen",
    headline: "ML Engineer | NLP, Document AI, MLOps",
    location: "Utrecht, NL",
    seniority: "mid",
    skills: ["python", "nlp", "information extraction", "llm", "mlops", "azure", "docker", "fastapi"],
    highlights: ["Automated document workflows with NLP", "Productionised models with CI/CD and monitoring"],
    sourceHint: "GitHub / portfolio",
  },
  {
    name: "Aylin Kaya",
    headline: "Lead Data Scientist | Operations Research & Optimisation",
    location: "Rotterdam, NL",
    seniority: "lead",
    skills: ["python", "optimisation", "operations research", "linear programming", "simulation", "stakeholder", "forecasting"],
    highlights: ["Designed workforce optimisation for logistics", "Led cross-functional analytics team"],
    sourceHint: "Conference talk page",
  },
  {
    name: "Thomas van Dijk",
    headline: "Senior Analytics Consultant | Supply Chain Planning",
    location: "Amsterdam, NL",
    seniority: "senior",
    skills: ["supply chain", "planning", "s&op", "forecasting", "stakeholder", "power bi", "sql", "python"],
    highlights: ["Implemented S&OP analytics playbooks", "Improved planning accuracy across 6 markets"],
    sourceHint: "Public bio",
  },
  {
    name: "Lotte Bakker",
    headline: "Data Scientist | Time-series & Causal Inference",
    location: "Haarlem, NL",
    seniority: "mid",
    skills: ["python", "time series", "forecasting", "bayesian", "causal inference", "pandas", "sql"],
    highlights: ["Forecasting pipelines for subscription products", "Experiment analysis and uplift modelling"],
    sourceHint: "Personal website",
  },
  {
    name: "Jeroen Smit",
    headline: "Senior Data Scientist | Azure Databricks | Retail Analytics",
    location: "Amersfoort, NL",
    seniority: "senior",
    skills: ["python", "pandas", "azure", "databricks", "forecasting", "feature engineering", "stakeholder"],
    highlights: ["Databricks lakehouse setup for analytics", "Forecasting + replenishment optimisation"],
    sourceHint: "LinkedIn / public profile",
  },
  {
    name: "Nina Peters",
    headline: "Junior Data Analyst | Supply Chain",
    location: "Amsterdam, NL",
    seniority: "junior",
    skills: ["sql", "excel", "power bi", "supply chain", "dashboards"],
    highlights: ["Built KPI dashboards for warehouse operations"],
    sourceHint: "Public resume",
  },
  {
    name: "David Romero",
    headline: "Senior Data Scientist | Demand Forecasting | NLP",
    location: "Berlin, DE",
    seniority: "senior",
    skills: ["python", "forecasting", "time series", "nlp", "information extraction", "stakeholder", "aws"],
    highlights: ["Forecasting for e-commerce demand", "NLP triage for customer operations"],
    sourceHint: "Public blog",
  },
];

const STOPWORDS = new Set([
  "the","and","or","a","an","to","for","with","of","in","on","at","as","we","you","your","our",
  "are","is","be","been","will","can","should","must","have","nice","plus","within","across","from",
  "senior","junior","lead","mid","data","scientist","engineer","analyst","manager","role","team","work",
  "hiring","looking","seeking","responsible","experience","years","year","hybrid","remote"
]);

function normaliseToken(t) {
  return (t || "")
    .toLowerCase()
    .replace(/[^a-z0-9+\-\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function extractKeywords(text) {
  const cleaned = normaliseToken(text);
  const rawTokens = cleaned.split(" ").filter(Boolean);

  // Simple phrase enrichment
  const phrases = [
    { p: "time series", keys: ["time", "series"] },
    { p: "operations research", keys: ["operations", "research"] },
    { p: "machine learning", keys: ["machine", "learning"] },
  ];

  const tokens = new Set();
  rawTokens.forEach(t => {
    if (t.length < 2) return;
    if (STOPWORDS.has(t)) return;
    tokens.add(t);
  });

  phrases.forEach(({ p, keys }) => {
    if (keys.every(k => rawTokens.includes(k))) tokens.add(p);
  });

  return Array.from(tokens);
}

function seniorityPenalty(candidateSeniority, desiredSeniority) {
  if (!desiredSeniority) return 0;
  const order = { junior: 1, mid: 2, senior: 3, lead: 4 };
  const c = order[candidateSeniority] || 2;
  const d = order[desiredSeniority] || 2;
  const diff = Math.abs(c - d);
  return diff === 0 ? 0 : diff === 1 ? 4 : 9;
}

function locationBonus(candidateLocation, desiredLocation) {
  if (!desiredLocation) return 0;
  const c = normaliseToken(candidateLocation);
  const d = normaliseToken(desiredLocation);
  if (!d) return 0;
  return c.includes(d) ? 8 : 0;
}

function scoreCandidate(candidate, keywords, desiredLocation, desiredSeniority) {
  const candidateSkills = candidate.skills.map(normaliseToken);
  const skillSet = new Set(candidateSkills);

  let overlap = 0;
  let strongHits = [];

  keywords.forEach(k => {
    const kk = normaliseToken(k);
    if (!kk) return;
    const hit = candidateSkills.some(s => s.includes(kk) || kk.includes(s));
    if (hit) {
      overlap += 1;
      if (strongHits.length < 6) strongHits.push(k);
    }
  });

  // Base score: overlap scaled
  const base = Math.min(70, overlap * 9);

  // Headline relevance: small boost
  const hl = normaliseToken(candidate.headline);
  const headlineBoost = keywords.some(k => hl.includes(normaliseToken(k))) ? 6 : 0;

  // Bonuses / penalties
  const loc = locationBonus(candidate.location, desiredLocation);
  const senPenalty = seniorityPenalty(candidate.seniority, desiredSeniority);

  const score = Math.max(0, Math.min(100, Math.round(base + headlineBoost + loc - senPenalty)));
  return { score, strongHits };
}

function makeSearchUrl(name, keywords) {
  const q = encodeURIComponent(`${name} ${keywords.slice(0, 4).join(" ")}`.trim());
  // Keep it generic (works as a demo without scraping)
  return `https://www.google.com/search?q=${q}`;
}

function renderCandidateCard(candidate, scoreInfo, keywords) {
  const card = document.createElement("div");
  card.className = "candidate-card";

  const link = makeSearchUrl(candidate.name, keywords);

  const hits = scoreInfo.strongHits.length
    ? scoreInfo.strongHits.map(h => `<span class="candidate-tag">${h}</span>`).join("")
    : `<span class="candidate-tag">General fit</span>`;

  card.innerHTML = `
    <div class="candidate-top">
      <div>
        <div class="candidate-name">${candidate.name}</div>
        <div class="candidate-headline">${candidate.headline}</div>
        <div class="candidate-meta">
          <span>📍 ${candidate.location}</span>
          <span>•</span>
          <span>Level: ${candidate.seniority}</span>
          <span>•</span>
          <span>${candidate.sourceHint}</span>
        </div>
      </div>
      <div class="candidate-score">
        <div class="candidate-score-number">${scoreInfo.score}</div>
        <div class="candidate-score-label">match</div>
      </div>
    </div>

    <div class="candidate-tags">${hits}</div>

    <ul class="candidate-highlights">
      ${(candidate.highlights || []).slice(0, 2).map(h => `<li>${h}</li>`).join("")}
    </ul>

    <div class="candidate-actions">
      <a class="candidate-link" href="${link}" target="_blank" rel="noopener noreferrer">Open web search <span>↗</span></a>
      <span class="candidate-note">(Demo link: opens a search query, no scraping.)</span>
    </div>
  `;

  return card;
}

function runMatching() {
  const vacancyText = vacancyTextEl ? vacancyTextEl.value : "";
  const desiredLocation = vacancyLocationEl ? vacancyLocationEl.value : "";
  const desiredSeniority = vacancySeniorityEl ? vacancySeniorityEl.value : "";

  const keywords = extractKeywords(vacancyText);

  const ranked = CANDIDATES
    .map(c => {
      const scoreInfo = scoreCandidate(c, keywords, desiredLocation, desiredSeniority);
      return { candidate: c, ...scoreInfo };
    })
    .sort((a, b) => b.score - a.score)
    .filter(x => x.score > 15)
    .slice(0, 8);

  // Render
  resultsList.innerHTML = "";
  if (!ranked.length) {
    resultsEmpty.style.display = "block";
    resultsCountPill.textContent = "0 results";
    return;
  }

  resultsEmpty.style.display = "none";
  resultsCountPill.textContent = `${ranked.length} result${ranked.length === 1 ? "" : "s"}`;

  ranked.forEach(r => {
    resultsList.appendChild(renderCandidateCard(r.candidate, { score: r.score, strongHits: r.strongHits }, keywords));
  });
}

if (findBtn) {
  findBtn.addEventListener("click", () => {
    runMatching();
    // Scroll results into view on mobile
    resultsList?.scrollIntoView?.({ behavior: "smooth", block: "start" });
  });
}
